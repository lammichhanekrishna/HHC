import javax.swing.*;  


public class Swing {
    
   public static void main(String args[])
  {
    String str1 = JOptionPane.showInputDialog("Enter your name");
    String str2 = JOptionPane.showInputDialog("Enter Professional License type number (1. Advance Practice 2. Temporary 3. Graduate 4. Registered) ");
                                   // input dialog returns always a string
    Control test = new Control();

    test.report(str1, str2);
 
    //JOptionPane.showMessageDialog( null, "Report generated", JOptionPane.INFORMATION_MESSAGE);
  }

}