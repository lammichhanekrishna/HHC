package com.app.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;


/**
 * @author ashishlamichhane
 * All database retrieve, CRUD operations.
 */
public class ApplicantDao 
{
	
	private DataSource dataSource;
	
	public ApplicantDao(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}
	
	
	
	public main.java.com.app.DTO.professionalLicenseDto getApplicantInfo(main.java.com.app.DTO.ApplicantDto applicant) throws Exception
	{
		
		main.java.com.app.DTO.professionalLicenseDto tempLicense= null;
		
		Connection myConnection = null;
		PreparedStatement myStatement = null;
		ResultSet myRs = null;
		
		try
		{
			myConnection = dataSource.getConnection();
			
			String sql ="SELECT * FROM professional_license where name = ? AND dob = ? "
					+ "AND driver_license_number = ? AND License_type = ? AND address = ? AND city = ? AND state = ? AND zipcode = ?";
			
			myStatement = myConnection.prepareStatement(sql);
			
			myStatement.setString(1, applicant.getFullName());
			myStatement.setString(2, applicant.getDob());
			myStatement.setString(3, applicant.getDriverLicense());
			myStatement.setString(4, applicant.getProfessionalLicense());
			myStatement.setString(5,  applicant.getAddress());
			myStatement.setString(6,  applicant.getCity());
			myStatement.setString(7, applicant.getState());
			myStatement.setString(8, applicant.getZipcode());
			
			myRs = myStatement.executeQuery();
			
			while(myRs.next())
			{
				String name = myRs.getString("name");
				String dob = myRs.getString("dob");
				String driverLicense = myRs.getString("driver_license_number");
				String address = myRs.getString("address");
				String city = myRs.getString("city");
				String state = myRs.getString("state");
				String zipcode = myRs.getString("zipcode");
				String Dl_issue_date = myRs.getString("DL_issue_date");
				String licenseType = myRs.getString("License_type");
				String status = myRs.getString("status");
				String issueDate = myRs.getString("issue_date");
				String expirationDate = myRs.getString("expiration_date");
				String disciplinaryAction = myRs.getString("disciplinary_action");
				
				tempLicense = new main.java.com.app.DTO.professionalLicenseDto(name, dob, driverLicense, address, city, state, zipcode, Dl_issue_date, licenseType, status, issueDate, expirationDate, disciplinaryAction);
			}
			

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			Close(myConnection, myStatement, myRs);
		}
		
		return tempLicense;

		
	}

	private void Close(Connection myConnection, Statement myStatement, ResultSet myRs) 
	{
		try
		{
			if(myConnection != null)
			{
				myConnection.close();
			}
			if(myStatement != null)
			{
				myStatement.close();
			}
			if(myRs != null)
			{
				myRs.close();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
