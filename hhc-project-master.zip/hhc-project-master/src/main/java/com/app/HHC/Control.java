package com.app.HHC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;


public class Control {

    public static void report(String name, String licenseType) {

        /** login session  - WE CAN CONVERT THIS TO THE FIELD IN SQL**/
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMdd");
        LocalDateTime now = LocalDateTime.now();
        String filepath = dtf.format(now) + ".txt";
        File tmpDir = new File(filepath);

        /** login session ended **/

        String db = "http://lbsearch.publicdata.com/pdsearch.php?";
        String details = "http://lbsearch.publicdata.com/pddetails.php?";
        boolean exists = tmpDir.exists();
        System.out.println(exists);

        if (tmpDir.exists()) {
            try {
                List<String> lines = Files.readAllLines(tmpDir.toPath());
                String user = lines.get(0);
                String ui = lines.get(1);
                String test = lines.get(2);
                String id = lines.get(4);
                JavaPostRequest post = new JavaPostRequest();
                ReadXMLFile read = new ReadXMLFile();
                System.out.println("Search link exists therefore no need to obtain a login session");
                System.out.println("Getting drivers license info");
                Control check = new Control();
                String medDb = check.checkLicense(Integer.valueOf(licenseType));
                String record = "";
                String info = "";

                /** record extraction **/
                record = read.driver(post.getPost(db, "input=txdl_dbs%7Cname&type=advanced&asiname=dlnum&p1=" + name + "&tacDMV=DPPATX-03&dlnumber=dzsw6801&id=" + id + "&disp=XML"));
                String license = read.driver(post.getPost(db, "input=" + medDb + "%7Cname&type=advanced&asiname=dlnum&p1=" + name + "&tacDMV=DPPATX-03&dlnumber=dzsw6801&id=" + id + "&disp=XML"));
                /*String criminal = read.driver(post.getPost(db, "input=grp_cri_tx_advanced_name%7Cname&type=advanced&asiname=dlnum&p1="+name+"&tacDMV=DPPATX-03&dlnumber=dzsw6801&id="+id+"&disp=XML"));*/
                List<String> dl = read.dlinfo(post.getPost(details, "db=txdl_dbs&rec=" + record + "&p1=" + name + "&tacDMV=DPPATX-03&dlnumber=dzsw6801&id=" + id + "&disp=XML"));
                //post.getPost(details, "db="+medDb+"&rec="+license+"&p1="+name+"&tacDMV=DPPATX-03&dlnumber=dzsw6801&id="+id+"&disp=XML");
                List<String> med = read.medinfo(post.getPost(details, "db=" + medDb + "&rec=" + license + "&p1=" + name + "&tacDMV=DPPATX-03&dlnumber=dzsw6801&id=" + id + "&disp=XML"), licenseType);
                /** record extraction **/

                check.write(dl, med, name);

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                JavaPostRequest post = new JavaPostRequest();
                ReadXMLFile read = new ReadXMLFile();
                read.searchlink(post.getPost("https://login.publicdata.com/pdmain.php/logon/checkAccess?disp=XML", "login_id=dzsw6801&password='p7tn6c"));
                Control check = new Control();
                check.report(name, licenseType);

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

    public static void write(List<String> dl, List<String> med, String name) {
        System.out.println(dl);
        System.out.println(med);
        String dlname = dl.get(0).replaceAll("\\s", "");
        ;
        String medname = med.get(0).replaceAll("\\s", "");
        ;
        String check = name.toUpperCase().replaceAll("\\s", "");
        ;

        boolean test = medname.equals(check);
        boolean test2 = dlname.equals(check);
        //System.out.println("Name :" +check + dlname + medname);
        // System.out.println("This is the first check: "+ test + " "+ test2);
        String tmdir = name + ".csv";

        try (PrintWriter writer = new PrintWriter(new File(name + ".csv"))) {

            StringBuilder sb = new StringBuilder();
            sb.append("Name");
            sb.append(',');
            sb.append("DOB");
            sb.append(',');
            sb.append("DL License Num");
            sb.append(',');
            sb.append("Address");
            sb.append(',');
            sb.append("DL Issue Date");
            sb.append(',');
            sb.append("Professional License Type");
            sb.append(',');
            sb.append("Prof. License Status");
            sb.append(',');
            sb.append("Prof. Licese Issue Date");
            sb.append(',');
            sb.append("Prof. License Expiration date");
            sb.append(',');
            sb.append("Disciplinary Actions");


            sb.append('\n');


            if (test2) {
                System.out.println("This is the accurate dl");
                sb.append(dl.get(0));
                sb.append(',');
                sb.append(dl.get(1));
                sb.append(',');
                sb.append(dl.get(3));
                sb.append(',');
                sb.append(dl.get(4));
                sb.append(',');
                sb.append(dl.get(5));
                sb.append(',');
            } else {
                System.out.println("This is not the accurate dl");
                for (int i = 0; i < 10; i++)
                    sb.append(',');

            }
            if (test) {
                System.out.println("This is the accurate med license");
                sb.append(med.get(3));
                sb.append(',');
                sb.append(med.get(1));
                sb.append(',');
                sb.append(med.get(5));
                sb.append(',');
                sb.append(med.get(6));
                sb.append(',');
                sb.append(med.get(7));


            } else {
                System.out.println("This is the inaccurate med license");
                for (int i = 0; i < 10; i++)
                    sb.append(',');
            }
            writer.write(sb.toString());
            System.out.println("done!");

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public String checkLicense(int type) {
        String response = "";
        if (type == 1) {
            response = "tx_pro_adv_prac_nurs";
        } else if (type == 2) {
            response = "tx_pro_temp_nurse";

        } else if (type == 3) {
            response = "tx_pro_grad_nurse";
        } else {
            response = "tx_pro_reg_nurse";

        }
        return response;
    }
}

