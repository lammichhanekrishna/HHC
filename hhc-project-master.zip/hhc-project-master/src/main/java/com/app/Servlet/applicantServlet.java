package com.app.Servlet;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.app.DAO.ApplicantDao;
import main.java.com.app.DTO.ApplicantDto;

import java.io.IOException;

/**
 * @author ashishlamichhane
 * doPost() doGet()...
 *
 *
 */
@WebServlet("/applicantServlet")
public class applicantServlet extends HttpServlet {

	@Resource(name="jdbc/hcp_verification_system")
	private DataSource dataSource;
	
	private ApplicantDao applicantDao;
	
	
	 @Override
		public void init() throws ServletException 
	    {
			// TODO Auto-generated method stub
			super.init();
			
			try
			{
				applicantDao = new ApplicantDao(dataSource);
			}
			catch(Exception e)
			{
				throw new ServletException(e);
			}
		}

    /**
     * Just for getting information form the SQL.
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
        
        try
        {
        	listProfessionalLicense(req, resp);
        }
        catch(Exception e)
        {
        	throw new ServletException(e);
        }
        
    }

    /**
     * For adding and editing.
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
    
    
    private void listProfessionalLicense(HttpServletRequest req, HttpServletResponse resp) throws Exception 
	{
		String name = req.getParameter("name");
		String dob = req.getParameter("dob");
		String driverLicense = req.getParameter("driverLicense");
		String licenseType = req.getParameter("license");
		String address = req.getParameter("address");
		String city = req.getParameter("city");
		String state = req.getParameter("state");
		String zipcode = req.getParameter("zipcode");
		
		ApplicantDto applicant = new ApplicantDto(name, dob, driverLicense, licenseType, address, city, state, zipcode);
		
		applicantDao.getApplicantInfo(applicant);
		
		listProfessionalLicense(req, resp);
		
		
	}


}
