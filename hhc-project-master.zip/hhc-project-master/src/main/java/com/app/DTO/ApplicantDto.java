package main.java.com.app.DTO;

/**
 * @author ashishlamichhane
 */
public class ApplicantDto {

    private int id;
    private String fullName;
    private String address;
    private String driverLicense;
    private String professionalLicense;
    private String dob;
    private String city;
    private String state;
    private String zipcode;
    

    public ApplicantDto(int id, String fullName, String address, String driverLicense, String professionalLicense,
			String dob, String city, String state, String zipcode) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.address = address;
		this.driverLicense = driverLicense;
		this.professionalLicense = professionalLicense;
		this.dob = dob;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}
    
    

	public ApplicantDto(String fullName, String address, String driverLicense, String professionalLicense, String dob,
			String city, String state, String zipcode) {
		super();
		this.fullName = fullName;
		this.address = address;
		this.driverLicense = driverLicense;
		this.professionalLicense = professionalLicense;
		this.dob = dob;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}



	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDriverLicense() {
        return driverLicense;
    }

    public void setDriverLicense(String driverLicense) {
        this.driverLicense = driverLicense;
    }

    public String getProfessionalLicense() {
        return professionalLicense;
    }

    public void setProfessionalLicense(String professionalLicense) {
        this.professionalLicense = professionalLicense;
    }
}

