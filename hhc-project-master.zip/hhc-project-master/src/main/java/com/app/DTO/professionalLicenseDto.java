package main.java.com.app.DTO;

public class professionalLicenseDto 
{

		private int id;
		private String name;
		private String dob;
		private String driverLicense;
		private String address;
		private String city;
		private String state;
		private String zipcode;
		private String dlIssueDate;
		private String licenseType;
		private String status;
		private String issueDate;
		private String expirationDate;
		private String disciplinaryAction;
		
		public professionalLicenseDto(int id, String name, String dob, String driverLicense, String address,
				String city, String state, String zipcode, String dlIssueDate, String licenseType, String status,
				String issueDate, String expirationDate, String disciplinaryAction) {
			super();
			this.id = id;
			this.name = name;
			this.dob = dob;
			this.driverLicense = driverLicense;
			this.address = address;
			this.city = city;
			this.state = state;
			this.zipcode = zipcode;
			this.dlIssueDate = dlIssueDate;
			this.licenseType = licenseType;
			this.status = status;
			this.issueDate = issueDate;
			this.expirationDate = expirationDate;
			this.disciplinaryAction = disciplinaryAction;
		}

		public professionalLicenseDto(String name, String dob, String driverLicense, String address, String city,
				String state, String zipcode, String dlIssueDate, String licenseType, String status, String issueDate,
				String expirationDate, String disciplinaryAction) {
			super();
			this.name = name;
			this.dob = dob;
			this.driverLicense = driverLicense;
			this.address = address;
			this.city = city;
			this.state = state;
			this.zipcode = zipcode;
			this.dlIssueDate = dlIssueDate;
			this.licenseType = licenseType;
			this.status = status;
			this.issueDate = issueDate;
			this.expirationDate = expirationDate;
			this.disciplinaryAction = disciplinaryAction;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDob() {
			return dob;
		}

		public void setDob(String dob) {
			this.dob = dob;
		}

		public String getDriverLicense() {
			return driverLicense;
		}

		public void setDriverLicense(String driverLicense) {
			this.driverLicense = driverLicense;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getZipcode() {
			return zipcode;
		}

		public void setZipcode(String zipcode) {
			this.zipcode = zipcode;
		}

		public String getDlIssueDate() {
			return dlIssueDate;
		}

		public void setDlIssueDate(String dlIssueDate) {
			this.dlIssueDate = dlIssueDate;
		}

		public String getLicenseType() {
			return licenseType;
		}

		public void setLicenseType(String licenseType) {
			this.licenseType = licenseType;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getIssueDate() {
			return issueDate;
		}

		public void setIssueDate(String issueDate) {
			this.issueDate = issueDate;
		}

		public String getExpirationDate() {
			return expirationDate;
		}

		public void setExpirationDate(String expirationDate) {
			this.expirationDate = expirationDate;
		}

		public String getDisciplinaryAction() {
			return disciplinaryAction;
		}

		public void setDisciplinaryAction(String disciplinaryAction) {
			this.disciplinaryAction = disciplinaryAction;
		}
		
		
		
		
}
