import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import org.xml.sax.InputSource;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.*;


public class ReadXMLFile {

  public static void searchlink(String file) {

    try {

	
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(new InputSource(new StringReader(file)));
			

	doc.getDocumentElement().normalize();

	//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
	NodeList nList = doc.getElementsByTagName("user");
			
	System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		//System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMdd");
			LocalDateTime now = LocalDateTime.now();
			String filename = (dtf.format(now) + ".txt");
			String dlnumber = eElement.getElementsByTagName("dlnumber").item(0).getTextContent();
			String dlstate = eElement.getElementsByTagName("dlstate").item(0).getTextContent();
			String id = eElement.getElementsByTagName("identifier").item(0).getTextContent();
			String session = eElement.getElementsByTagName("sessionid").item(0).getTextContent();
			String unique = eElement.getElementsByTagName("id").item(0).getTextContent();
			try{
				FileWriter writer = new FileWriter(filename, true);
				writer.write(dlnumber);
				writer.write("\r\n");
				writer.write(dlstate);
				writer.write("\r\n");
				writer.write(id);
				writer.write("\r\n");
				writer.write(session);
				writer.write("\r\n");
				writer.write(unique);
				writer.close();
			}
			catch (IOException e){
				e.printStackTrace();
			}
			/*System.out.println("Search Test : " + eElement.getElementsByTagName("searchserver").item(0).getTextContent());*/



		}
	}
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

	String driver(String file) {
		String record = "";

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(file)));
			doc.getDocumentElement().normalize();

			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("record");
			//System.out.println("----------------------------");
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				//System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					//System.out.println("Record Number : " + eElement.getAttribute("rec"));
					/*System.out.println("Search Test : " + eElement.getElementsByTagName("searchserver").item(0).getTextContent());*/
                    record = eElement.getAttribute("rec").toString();




				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return record.toString(); }

	public static List<String> dlinfo(String file){


		try {


			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(file)));


			doc.getDocumentElement().normalize();

			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName("textdata");
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);
				//System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					String first = eElement.getElementsByTagName("field").item(0).getTextContent();
					String middle = eElement.getElementsByTagName("field").item(1).getTextContent();
					String last = eElement.getElementsByTagName("field").item(2).getTextContent();
					String licensenum = eElement.getElementsByTagName("field").item(4).getTextContent();
					String licensetype = eElement.getElementsByTagName("field").item(5).getTextContent();
					String street = eElement.getElementsByTagName("field").item(6).getTextContent();
					String street2 = eElement.getElementsByTagName("field").item(9).getTextContent();
					String dob = eElement.getElementsByTagName("field").item(8).getTextContent();
					String issue = eElement.getElementsByTagName("field").item(10).getTextContent();
                    String fullName = first +" "+ middle + " "+ last;
                    String address = street+ " "+ street2;

					System.out.println("Name: "+ fullName);
					System.out.println("Date of Birth: "+ dob);
					System.out.println("License Type: "+ licensetype);
					System.out.println("License num: " + licensenum);
					System.out.println("Address: "+ address );
					System.out.println("Issue data: "+ issue);
					return Arrays.asList(fullName, dob, licensetype, licensenum,address,issue);
					//System.out.println("Record Number : " + eElement.getAttribute("rec"));
					/*System.out.println("Search Test : " + eElement.getElementsByTagName("searchserver").item(0).getTextContent());*/
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
  	return  null;
	}

	public static List<String> medinfo(String file, String type){
		try {


			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(file)));


			doc.getDocumentElement().normalize();

			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList nList = doc.getElementsByTagName("textdata");
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);
				//System.out.println("\nCurrent Element :" + nNode.getNodeName());
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					if (type.equals("1") || type.equals("3")) {
						String name = eElement.getElementsByTagName("field").item(0).getTextContent();
						String status = eElement.getElementsByTagName("field").item(1).getTextContent();
						String presc = eElement.getElementsByTagName("field").item(2).getTextContent();
						String medtype = eElement.getElementsByTagName("field").item(3).getTextContent();
						String address = eElement.getElementsByTagName("field").item(4).getTextContent();
						String iss = eElement.getElementsByTagName("field").item(5).getTextContent();
						String exp = eElement.getElementsByTagName("field").item(6).getTextContent();
						String discipline = eElement.getElementsByTagName("field").item(10).getTextContent();


						System.out.println("Name: " + name);
						System.out.println("License Status: "+ status);
						System.out.println("Prescriptive Status: "+ presc);
						System.out.println("License type: " + medtype);
						System.out.println("Address: " + address);
						System.out.println("Issue date: " + iss);
						System.out.println("Exp date: "+ exp );
						System.out.println("Disciplinary action: "+ discipline);
						return Arrays.asList(name, status, presc, medtype,address,iss, exp, discipline);
						//System.out.println("Record Number : " + eElement.getAttribute("rec"));
						/*System.out.println("Search Test : " + eElement.getElementsByTagName("searchserver").item(0).getTextContent());*/
					} else if(type.equals("2") || type.equals("4")){

						String name = eElement.getElementsByTagName("field").item(0).getTextContent();
						String status = eElement.getElementsByTagName("field").item(1).getTextContent();
						String presc = eElement.getElementsByTagName("field").item(2).getTextContent();
						String medtype = eElement.getElementsByTagName("field").item(3).getTextContent();
						String address = eElement.getElementsByTagName("field").item(4).getTextContent();
						String iss = eElement.getElementsByTagName("field").item(5).getTextContent();
						String exp = eElement.getElementsByTagName("field").item(6).getTextContent();
						String com = eElement.getElementsByTagName("field").item(7).getTextContent();
						String disc = eElement.getElementsByTagName("field").item(8).getTextContent();

						System.out.println("Name: " + name );
						System.out.println("License Status: " + status);
						System.out.println("License Type: " + medtype);
						System.out.println("Prescription Status: "+ presc);
						System.out.println("Address: " + address);
						System.out.println("Issue date: " + iss);
						System.out.println("Exp date: "+ exp );
						System.out.println("Exp date: "+ com );
						System.out.println("Disciplinary action: "+ disc);
						return Arrays.asList(name, status, presc, medtype,address,iss, exp, disc);



					}

					else {

						System.out.println("Invalid License Type");

					}

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
  	   return null;
	}

}